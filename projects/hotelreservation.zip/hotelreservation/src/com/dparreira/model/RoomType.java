package com.dparreira.model;

public enum RoomType {
  SINGLE,
  DOUBLE
}

