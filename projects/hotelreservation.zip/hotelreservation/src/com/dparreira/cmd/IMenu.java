package com.dparreira.cmd;

interface IMenu {
  public static void printOptions() { }

  public static Integer selectAnOption() {
    return null;
  }

  public static void triggerOption(Integer option) { }
}
