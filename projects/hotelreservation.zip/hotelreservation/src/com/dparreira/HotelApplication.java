package com.dparreira;

import com.dparreira.cmd.MainMenu;

public class HotelApplication {

    public static void main(String[] args) {
        MainMenu.printOptions();
    }
}
